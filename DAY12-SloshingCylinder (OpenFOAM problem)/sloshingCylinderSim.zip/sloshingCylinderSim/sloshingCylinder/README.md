* mkdir constant/triSurface
* cp -r 0_orig 0
* blockMesh
* snappyHexMesh -overwrite
* setFields
* interFoam
